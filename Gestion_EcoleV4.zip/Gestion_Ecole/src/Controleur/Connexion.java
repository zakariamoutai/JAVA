/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

/*
 * 
 * Librairies importées
 */

import java.sql.*;

/**
 * 
 * Connexion a votre BDD locale 
 * 
 * @author rahli, moutai
 */
public class Connexion {

    /**
     * Attributs prives : connexion JDBC, statement
     * requete
     */
    private Connection conn;
    private Statement stmt;
    /**
     * Constructeur avec 4 paramètres : serveur,nom, login et password de la BDD locale
     *
     * @param serveurDB
     * @param nameDB
     * @param loginDB
     * @param passDB
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    public Connexion(String serveurDB,String nameDB, String loginDB, String passDB)throws SQLException, ClassNotFoundException {
        
            String urlDatabase = "jdbc:mysql://"+serveurDB+":3306/"+nameDB;
            Class.forName("com.mysql.jdbc.Driver");    
            conn = DriverManager.getConnection(urlDatabase,loginDB,passDB);
            stmt = conn.createStatement();

    }

}