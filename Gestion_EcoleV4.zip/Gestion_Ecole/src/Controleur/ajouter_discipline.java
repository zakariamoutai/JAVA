/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

import Controleur.ConnexionContinue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author Moutai Zakaria
 */
public class ajouter_discipline extends JFrame {
    
    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;

    private JPanel jPanel1;
    private JTextField discipline_eleve;
  
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
	
    public ajouter_discipline()
    {     
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        
        discipline_eleve = new JTextField();
        jButton1 = new JButton();
        
        
        setSize(580,390); //Taille de la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre


        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));


        jLabel2.setFont(new java.awt.Font("Times New Roman", 2, 48)); // NOI18N
        jLabel2.setText("Rensignements");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 20, 380, 56);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel3.setText("Discipline :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 130, 180, 50);
    
        jPanel1.add(discipline_eleve);
        discipline_eleve.setBounds(220, 140, 220, 30);


        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 260);

        
        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Ajouter");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);

        
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
               
                String diselev =discipline_eleve.getText();
                String Ajouter= "INSERT INTO discipline VALUES("+0+",'"+diselev+"')";
                
                //TENTATIVE DE CONNEXION
                try 
                {   
                    stmt=connex.etablirconnection().createStatement();
                    stmt.executeUpdate(Ajouter);
                    JOptionPane.showMessageDialog(null,"Les renseignements ont bien été ajouté.");
                    discipline_eleve.setText("");
                   
                }
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
              
        });
        
        
        setVisible(true); //Rendre visible la fenetre
        
    }
    
}
