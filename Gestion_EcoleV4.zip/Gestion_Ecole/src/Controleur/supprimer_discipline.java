/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

import Controleur.ConnexionContinue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author Moutai Zakaria
 */
public class supprimer_discipline extends JFrame {
    
    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;

    private JPanel jPanel1;

  private JTextField id_eleve;
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
	
    public supprimer_discipline()
    {     
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        

        id_eleve = new JTextField();
        jButton1 = new JButton();
        
        
        setSize(580,390); //Taille de la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre


        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));


        jLabel2.setFont(new java.awt.Font("Times New Roman", 2, 48)); // NOI18N
        jLabel2.setText("Rensignements");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 20, 380, 56);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel3.setText("Id discpline:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 90, 210, 50);

        
        jPanel1.add(id_eleve);
        id_eleve.setBounds(220, 100, 220, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 260);

        
        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Supprimer");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);

        
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
               
                String ideleve =id_eleve.getText();
                
                
               try {
             if(JOptionPane.showConfirmDialog(null,"attention vous avez supprimer un etudient,est ce que tu et sure?"
                     ,"supprimer etudient",JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION)
         
            if(ideleve.length() != 0){
                stmt=connex.etablirconnection().createStatement();
                stmt.executeUpdate("Delete From discipline where id_discipline = "+ideleve);
                JOptionPane.showMessageDialog(null,"La suppression a bien été opéré.");
             }//ca est pour recharger la list des stagiaire
            else { JOptionPane.showMessageDialog(null,"veuillez remplire le champ id !");}
        
        }catch (Exception e){JOptionPane.showMessageDialog(null,"erreur de supprimer \n"+e.getMessage());} 
            }
              
        });
        
        
        setVisible(true); //Rendre visible la fenetre
        
    }
    
}