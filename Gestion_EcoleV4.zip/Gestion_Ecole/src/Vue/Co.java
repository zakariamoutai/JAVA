/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import java.sql.Connection;
import java.sql.SQLException;

import java.util.logging.Level;
import Controleur.*;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author rahli
 */
public class Co extends JFrame {
                      
    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JPanel jPanel1;
    private JTextField serveur;
    private JTextField name;
    private JTextField username;
    private JTextField password;

    /**
     * Créer grace à une interface
     */
    public Co() 
    {
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();    
        serveur = new JTextField();
        name = new JTextField();
        username = new JTextField();
        password = new JTextField();
        jButton1 = new JButton();
     
        setSize(565,400); //Taille de la fenetre
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre

        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("Password :");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 210, 120, 50);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 2, 48)); // NOI18N
        jLabel2.setText("Page de Connexion");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 20, 380, 56);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel3.setText("Serveur de la base :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 90, 210, 50);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel4.setText("Nom de la base :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 130, 180, 50);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel5.setText("Login :");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(10, 170, 100, 50);
        
        jPanel1.add(serveur);
        serveur.setBounds(220, 100, 220, 30);
    
        jPanel1.add(name);
        name.setBounds(220, 140, 220, 30);

        jPanel1.add(username);
        username.setBounds(220, 180, 220, 30);

        jPanel1.add(password);
        password.setBounds(220, 220, 220, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 260);

        
        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Connexion");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
                String serveurDataBase=serveur.getText(); 
                String nameDataBase=name.getText();
                String login=username.getText(); 
                String pass=password.getText();
                
                //TENTATIVE DE CONNEXION
                try 
                {  
                    new Connexion(serveurDataBase,nameDataBase,login,pass);
                    setVisible(false);
                    JOptionPane.showMessageDialog(null,"Connexion réussie"); 
                    new AccueilI();                  
                } 
                catch (SQLException |  ClassNotFoundException ex) 
                {
                    Logger.getLogger(Co.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        this.setVisible(true); //Rendre visible la fenetre

    }
                     
}
