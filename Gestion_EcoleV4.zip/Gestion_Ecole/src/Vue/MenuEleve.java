/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author rahli
 */
public class MenuEleve extends javax.swing.JFrame {

    // Variables                 
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    
    /**
     * Constructeur pour le menu des élèves
     */
    public MenuEleve() 
    {
        initComponents();
    }

    /**
     *Méthode qui initialise la fenetre permettant d'afficher le menu des élèves
     */                        
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setSize(590,380); //Taille de la fenetre
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre

        jButton1.setBackground(new java.awt.Color(255, 0, 51));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton1.setText("Liste des éléves");
        jButton1.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
                new ListeEleve();
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(30, 80, 140, 60);

        jButton2.setBackground(new java.awt.Color(0, 204, 0));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton2.setText("Mon bulletin");
        jButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) 
            {      
                new ConnexionEleveI();            
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(210, 80, 160, 60);

        jButton3.setBackground(new java.awt.Color(255, 204, 0));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jButton3.setText("Liste des classes");
        jButton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt)   
            {
                new ListeClasse();
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(410, 80, 150, 60);

        jButton4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton4.setText("RECHERCHE");
        jButton4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) 
            {
                new RechercheEleve();
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(230, 280, 130, 30);
        
        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jButton5.setText("Retour");
        jButton5.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
                setVisible(false);
                JOptionPane.showMessageDialog(null,"Retour au menu"); 
                new RechercheI();        
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(10, 10, 80, 23);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/fond_ecran_eleve.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 604, 340);

        this.setVisible(true);
    }                      

            
}