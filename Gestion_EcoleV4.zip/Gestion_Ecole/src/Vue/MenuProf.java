/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author rahli
 */
public class MenuProf extends javax.swing.JFrame {

    // Variables                     
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
      
    /**
     * Constructeur Pour le menu d'un prof
     */
    public MenuProf() 
    {
        initComponents();
    }

    /**
     * Méthode qui initialise la fenetre permettant d'afficher le menu des profs
     */                            
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();     
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setSize(520,340); //Taille de la fenetre
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre

        jButton1.setBackground(new java.awt.Color(255, 0, 51));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jButton1.setText("Liste des professeurs");
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            {
                new ListeProf();
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 100, 163, 60);

        jButton2.setBackground(new java.awt.Color(0, 204, 0));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jButton2.setText("Liste des disciplines");
        jButton2.addActionListener(new java.awt.event.ActionListener() 
        {
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            {
                new ListeDiscipline();
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(180, 100, 160, 60);

        jButton3.setBackground(new java.awt.Color(255, 204, 0));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jButton3.setText("Liste des bulletins");
        jButton3.addActionListener(new java.awt.event.ActionListener() 
        {
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            {
                new Bulletin();
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(350, 100, 140, 60);
        
        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jButton5.setText("Retour");
        jButton5.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent evt) 
            {
                setVisible(false);
                JOptionPane.showMessageDialog(null,"Retour au menu"); 
                new RechercheI();        
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(10, 10, 80, 23);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/proff.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 510, 320);

        setVisible(true);
    }                                                   
    
                    
}