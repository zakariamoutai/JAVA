/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modèle;

/**
 *Discipline
 * @author rahli
 */
public class Discipline {
    private String NomD;
    
    /**
    *Constructeur Discipline
    * 
    */
    public Discipline(){
        NomD=null;
    }
    
}
