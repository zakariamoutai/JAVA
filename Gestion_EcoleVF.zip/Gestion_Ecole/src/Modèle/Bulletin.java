/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modèle;

/**
 *Bulletin
 * @author rahli
 */
public class Bulletin {
    private int Trimestre;
    private Eleve EleveB;
    private String appreciation;
    
    /**
    *Constructeur Bulletin
    * 
    */
    public Bulletin(){
        Trimestre=0;
        EleveB=null;
        appreciation=null;
        
    }
}
