/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modèle;
/**
 *Enseignant
 * @author rahli
 */
public class Prof {
    private String nomProf;
    private String prenomProf;
    private Discipline d;
    private Classe c;
    
    /**
    *Constructeur Prof
    * 
    */
    public Prof()
    {
        nomProf=null;
        prenomProf=null;
        d=null;
        c=null;
        
    }   
    
}