/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

/**
 *Ajout d'un prof
 * @author Moutai Zakaria
 */
public class ajouter_prof extends JFrame {
    
    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;

    private JPanel jPanel1;
    private JTextField nom_eleve;
    private JTextField discipline_eleve;
  
    private JTextField classe_eleve;
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
	/**
    *Ajout prof
    */
    public ajouter_prof()
    {     
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        
        nom_eleve = new JTextField();
        discipline_eleve = new JTextField();
        classe_eleve = new JTextField();
        jButton1 = new JButton();
        
        
        setSize(580,390); //Taille de la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre


        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));


        jLabel2.setFont(new java.awt.Font("Times New Roman", 2, 38)); // NOI18N
        jLabel2.setText("AJOUT ENSEIGNANT");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 20, 380, 56);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel3.setText("Classe :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 90, 210, 50);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel4.setText("Discipline :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 130, 180, 50);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel5.setText("Nom :");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(10, 170, 100, 50);
        
        jPanel1.add(classe_eleve);
        classe_eleve.setBounds(220, 100, 220, 30);
    
        jPanel1.add(discipline_eleve);
        discipline_eleve.setBounds(220, 140, 220, 30);

        jPanel1.add(nom_eleve);
        nom_eleve.setBounds(220, 180, 220, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 260);

        
        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Ajouter");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);

        
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
               
                String nameelev =nom_eleve.getText(); 
                String diselev =discipline_eleve.getText();
                String classeelev =classe_eleve.getText();
                String Ajouter= "INSERT INTO enseignement VALUES("+0+",'"+classeelev+"','"+diselev+"','"+nameelev+"')";
                
                //TENTATIVE DE CONNEXION
                try 
                {   if(nameelev.length() != 0&&diselev.length() != 0&&classeelev.length() != 0)
                    {
                    stmt=connex.etablirconnection().createStatement();
                    stmt.executeUpdate(Ajouter);
                    JOptionPane.showMessageDialog(null,"Enseignant Ajouté");
                    nom_eleve.setText("");
                    discipline_eleve.setText("");
                    classe_eleve.setText("");
                    }
                    else 
                    { JOptionPane.showMessageDialog(null,"Champ manquant");}
                   
                }
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
              
        });
        
        
        setVisible(true); //Rendre visible la fenetre
        
    }
    
}
