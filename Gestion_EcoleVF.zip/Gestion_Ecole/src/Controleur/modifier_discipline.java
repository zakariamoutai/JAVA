/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;


import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

/**
 *Modifier discipline
 * @author Moutai Zakaria
 */
public class modifier_discipline extends JFrame {
    
    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;

    private JPanel jPanel1;
    private JTextField discipline;
    private JTextField id_discipline;
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
    /**
    *Modifier Discipline
    */
    public modifier_discipline()
    {     
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        
        discipline = new JTextField();
        id_discipline = new JTextField();
        jButton1 = new JButton();
        
        
        setSize(580,390); //Taille de la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre


        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));


        jLabel2.setFont(new java.awt.Font("Times New Roman", 2, 30)); // NOI18N
        jLabel2.setText("MODIFICATION DISCIPLINE");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 20, 380, 56);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel3.setText("Discipline :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 90, 210, 50);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel4.setText("Id :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 130, 180, 50);

        
        jPanel1.add(discipline);
        discipline.setBounds(220, 100, 220, 30);
    
        jPanel1.add(id_discipline);
        id_discipline.setBounds(220, 140, 220, 30);


        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 260);

        
        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Modifier");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);

        
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
               

                String diseleve =discipline.getText();
                String iddisc =id_discipline.getText();
                
                
                try { 
                    if (JOptionPane.showConfirmDialog (null,"Etes-vous sur de vouloir modifier?","Modification",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) 
                    {
                        if(iddisc.length() != 0&&diseleve.length() != 0)
                        {

                        stmt=connex.etablirconnection().createStatement();
                        stmt.executeUpdate("UPDATE discipline SET nom='"+diseleve+"' WHERE id_discipline= "+iddisc);
                        JOptionPane.showMessageDialog(null,"Discipline modifié");
                        discipline.setText("");
                        id_discipline.setText("");
                        }
                        else 
                        { JOptionPane.showMessageDialog(null,"Champ manquant");}
           
                    } 
                }
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
        
            }
            
              
        });
        
        
        setVisible(true); //Rendre visible la fenetre
        
    }
    
}
