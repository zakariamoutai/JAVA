/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

/**
 *Avoir le nombre d'eleve
 * @author rahli,moutai
 */
public class NombreE  {
    
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
	
    public NombreE()
    {  
               
        String req= "SELECT COUNT(Nom) FROM eleve";

        //TENTATIVE DE CONNEXION
        try 
        {   
            stmt=connex.etablirconnection().createStatement();
            ResultSet res=stmt.executeQuery(req);
            res.next();
            int nb=res.getInt(1);
            JOptionPane.showMessageDialog(null,nb);
        }
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
        
         
        
    }
    
}
