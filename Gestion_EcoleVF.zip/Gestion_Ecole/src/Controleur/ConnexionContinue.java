/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *Connexion a la BDD locale en continue 
 * @author rahli, moutai
 */


public class ConnexionContinue  {
	
        /**
         * Attributs prives : connexion JDBC
         */
	private Connection con; 
        /**
        *Constructeur pour pouvoir se connecter à la bdd
        */
	public ConnexionContinue()
	{
            try 
            {
                Class.forName("com.mysql.jdbc.Driver");  
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gestionecole","root","");
                System.out.println("connexion établie");
            } 
            catch (Exception e) 
            {
                    System.out.println("Base de donneee introuvable");
            }
	}
        
        /**
         * Méthode qui permet d'etablir la connexion
         * @return con
         */
	public Connection etablirconnection() 
        {
		return con;
	}
}
