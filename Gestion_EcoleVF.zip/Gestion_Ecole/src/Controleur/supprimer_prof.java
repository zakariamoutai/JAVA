/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

import java.sql.Statement;
import javax.swing.*;

/**
 *supp Prof
 * @author Moutai Zakaria
 */
public class supprimer_prof extends JFrame {
    
    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;

    private JPanel jPanel1;

    private JTextField id_enss;
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
    /**
    *Supprimer prof
    */
    public supprimer_prof()
    {     
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        

        id_enss = new JTextField();
        jButton1 = new JButton();
        
        
        setSize(580,390); //Taille de la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre


        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));


        jLabel2.setFont(new java.awt.Font("Times New Roman", 2, 35)); // NOI18N
        jLabel2.setText("SUPPRESSION PROF");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 20, 380, 56);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel3.setText("Id Professeur:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 90, 210, 50);

        
        jPanel1.add(id_enss);
        id_enss.setBounds(220, 100, 220, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 260);

        
        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Supprimer");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);

        
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
               
                String idprof =id_enss.getText();
                
                
                try {
                    if(JOptionPane.showConfirmDialog(null,"Etes-vous sur de vouloir supprimer?"
                             ,"Suppression",JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION)

                    if(idprof.length() != 0)
                    {
                        stmt=connex.etablirconnection().createStatement();
                        stmt.executeUpdate("Delete From enseignement where id_ens = "+idprof);
                        JOptionPane.showMessageDialog(null,"Prof supprimé");
                    }
                    else { JOptionPane.showMessageDialog(null,"Champ manquant");}

                }catch (Exception e){JOptionPane.showMessageDialog(null,"erreur");} 
            }
              
        });
        
        
        setVisible(true); //Rendre visible la fenetre
        
    }
    
}