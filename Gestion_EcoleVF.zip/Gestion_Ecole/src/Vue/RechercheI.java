/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import javax.swing.*;

/**
 *
 * @author rahli
 */
public class RechercheI extends javax.swing.JFrame {
    
    // Variables declaration - do not modify                     
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration     

    /**
     * Menu Recherche
     */
    public RechercheI() 
    {
        jButton1 = new JButton();
        jButton2 = new JButton();
        jButton3 = new JButton();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel5 = new JLabel();
        jLabel1 = new JLabel();
        
        setSize(510,370); //Taille de la fenetre
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre

        jButton1.setBackground(new java.awt.Color(51, 255, 255));
        jButton1.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton1.setText("ELEVE");
        getContentPane().add(jButton1);
        jButton1.setBounds(70, 240, 130, 50);

        jButton2.setBackground(new java.awt.Color(51, 255, 255));
        jButton2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton2.setText("PROFESSEUR");
        getContentPane().add(jButton2);
        jButton2.setBounds(310, 240, 140, 50);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jButton3.setText("Accueil");
        getContentPane().add(jButton3);
        jButton3.setBounds(10, 10, 80, 23);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/eleve.png"))); 
        getContentPane().add(jLabel2);
        jLabel2.setBounds(70, 90, 130, 140);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/prof.png"))); 
        getContentPane().add(jLabel3);
        jLabel3.setBounds(310, 88, 140, 140);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/titrerech.png"))); 
        getContentPane().add(jLabel5);
        jLabel5.setBounds(140, 20, 230, 60);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ecole.jpg"))); 
        getContentPane().add(jLabel1);
        jLabel1.setBounds(-6, -6, 510, 340);
    
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            {
                setVisible(false);
                new MenuEleve();
            }
        });

        jButton2.addActionListener(new java.awt.event.ActionListener() 
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt) 
                {   
                    setVisible(false);
                    new MenuProf();
                    
                           
                }
            });

        jButton3.addActionListener(new java.awt.event.ActionListener() 
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt) 
                {
                    setVisible(false);
                    JOptionPane.showMessageDialog(null,"Retour à l'acceuil"); 
                    new AccueilI();        
                }
            });

        this.setVisible(true);
    }


    

                  
}