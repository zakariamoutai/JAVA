/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author Moutai Zakaria
 */
public class ajouter_eleve extends JFrame {
    
    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;

    private JPanel jPanel1;
    private JTextField nom_eleve;
    private JTextField prenom_eleve;
    private JTextField id_eleve;
    private JTextField classe_eleve;
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
	
    public ajouter_eleve()
    {     
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        id_eleve = new JTextField();
        nom_eleve = new JTextField();
        prenom_eleve = new JTextField();
        classe_eleve = new JTextField();
        jButton1 = new JButton();
     
        setSize(565,400); //Taille de la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre

        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        

        jLabel1.setFont(new java.awt.Font("Times New Roman", 2, 33)); // NOI18N
        jLabel1.setText("Veuillez renseigner les informations de l'élève");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(40, 20, 380, 56);
        
        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 28)); // NOI18N
        jLabel2.setText("Id :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 90, 210, 50);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 28)); // NOI18N
        jLabel3.setText("Nom :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 90, 210, 50);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 28)); // NOI18N
        jLabel4.setText("Prénom :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 130, 180, 50);
        
        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 28)); // NOI18N
        jLabel5.setText("Classe :");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(10, 130, 180, 50);

        jPanel1.add(id_eleve);
        id_eleve.setBounds(220, 100, 220, 30);
        
        jPanel1.add(nom_eleve);
        nom_eleve.setBounds(220, 100, 220, 30);
    
        jPanel1.add(prenom_eleve);
        prenom_eleve.setBounds(220, 140, 220, 30);
        
        jPanel1.add(classe_eleve);
        classe_eleve.setBounds(220, 140, 220, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 200);

        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Ajouter");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
                String Id =id_eleve.getText();
                String Nom =nom_eleve.getText(); 
                String Prenom =prenom_eleve.getText();
                String Classe =classe_eleve.getText();
                String Ajouter= "insert into eleve (id_eleve, Nom, Prenom, ClasseEleve) VALUES ('"+Id+"','"+Nom+"','"+Prenom+"','"+Classe+"')";
                //TENTATIVE DE CONNEXION
                try 
                {   
                    stmt.executeUpdate(Ajouter);
                    JOptionPane.showMessageDialog(null,"Les renseignements ont bien été ajouté.");
                   
                }
                catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
              
        });
        
        
        setVisible(true); //Rendre visible la fenetre
        
    }
    
}

