/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author rahli
 */


public class RequeteRechercheEleve {
    
    ConnexionContinue con = new ConnexionContinue();
    Statement stmt;
    public RequeteRechercheEleve(String req,ResultSet resultat ) throws SQLException
    {   
        stmt=con.etablirconnection().createStatement();
        resultat =stmt.executeQuery(req);      
    }
}
