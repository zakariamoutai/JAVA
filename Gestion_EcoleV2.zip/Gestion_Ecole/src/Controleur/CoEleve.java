/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;


import java.sql.*;

/**
 *
 * @author rahli
 */
public class CoEleve extends ConnexionContinue {
    
    Connection con;
    Statement st;
    public CoEleve() throws ClassNotFoundException, SQLException
    {
        super();
        String c,p;
        String req="SELECT * FROM users WHERE Nom='"+c+"' and ='"+p+"'"; 

        try 
        {
            st=kk.etablirconnection().createStatement();
            rt=st.executeQuery(query);

            if(rt.next()) {

                    if(c.equalsIgnoreCase(rt.getString("login")) && p.equalsIgnoreCase(rt.getString("password")))
                    {


                            f.setVisible(true); 
                            dispose();


                    }


            }

            else 
                    JOptionPane.showMessageDialog(null, "Petit toi aussi arrête doublier ton login ou password ka merde wai");

        } catch (SQLException e) {


                //e.printStackTrace();
        }
        
    }
}
