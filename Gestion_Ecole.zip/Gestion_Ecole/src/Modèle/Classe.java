/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modèle;

/**
 *
 * @author rahli
 */
public class Classe {
    
    private String nomClasse;
    private String niveauClasse;
    private String Annee;
    
    public Classe(){
        nomClasse=null;
        niveauClasse=null;
        Annee=null;
        
    }
    
}
