/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Controleur.Connexion;
import Controleur.ConnexionContinue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
/**
 *
 * @author rahli
 */
public class RechercheEleve extends JFrame {
    

    private JButton jButton1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;

    private JPanel jPanel1;
    private JTextField nom_eleve;
    private JTextField prenom_eleve;
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();
    
    
	
    public RechercheEleve()
    {     
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
           
        nom_eleve = new JTextField();
        prenom_eleve = new JTextField();
        jButton1 = new JButton();
     
        setSize(565,400); //Taille de la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        getContentPane().setLayout(null);
        setLocationRelativeTo(null); //Fenetre au centre

        jPanel1.setLayout(null);
        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        

        jLabel1.setFont(new java.awt.Font("Times New Roman", 2, 33)); // NOI18N
        jLabel1.setText("Page de Connexion Eleve");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(40, 20, 380, 56);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 28)); // NOI18N
        jLabel2.setText("Nom :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 90, 210, 50);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 28)); // NOI18N
        jLabel3.setText("Prénom :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 130, 180, 50);

    
        jPanel1.add(nom_eleve);
        nom_eleve.setBounds(220, 100, 220, 30);
    
        jPanel1.add(prenom_eleve);
        prenom_eleve.setBounds(220, 140, 220, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(80, 40, 460, 200);

        jButton1.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jButton1.setText("Rechercher");
        getContentPane().add(jButton1);
        jButton1.setBounds(230, 310, 130, 40);
        
        jButton1.addActionListener(new java.awt.event.ActionListener() 
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) 
            { 
                //Récupére les valeurs tapés
                String login=nom_eleve.getText(); 
                String pass=prenom_eleve.getText();
                
                //TENTATIVE DE CONNEXION
                try 
                {   
                    stmt=connex.etablirconnection().createStatement();
                    ResultSet res =stmt.executeQuery("SELECT * FROM eleve,bulletin WHERE Nom='"+login+"' and Prenom='"+pass+"'");
                    if(res.next())
                    {
                        if((login.equalsIgnoreCase(res.getString("Nom"))) && (pass.equalsIgnoreCase(res.getString("Prenom"))))
                        {
                            setVisible(false);
                            
                             
                        }
                        
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Champs manquant ou Nom/Prenom incorrect");
                    }
                }
                catch (SQLException ex) 
                {
                    Logger.getLogger(ConnexionEleveI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
              
        });
        
        
        setVisible(true); //Rendre visible la fenetre
        
    }
    
    
    
}
