package Vue;



import Controleur.ConnexionContinue;
import java.sql.*;


import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;




import javax.swing.*;

public class ListeEleve extends JFrame
{
    
    //Variables 
    private JScrollPane tab;
    private JTable tabelev;
    private JLabel jLabel1;
    Statement stmt;
    ConnexionContinue connex = new ConnexionContinue();

    /**
     * Constructeur qui affiche la liste des éléves 
     */
    public ListeEleve() {

        setSize(565,400); //Taille de la fenetre
        //setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        setLocation(500, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLocationRelativeTo(null); //Fenetre au centre
        
        initComponents();
        
        DefaultTableModel model=new DefaultTableModel();
        
        model.addColumn("Id");
        model.addColumn("Nom");
        model.addColumn("Prénom");
        model.addColumn("Classe");
        tabelev.setModel(model);
        
        try
        {
            stmt=connex.etablirconnection().createStatement();
            ResultSet resultat =stmt.executeQuery("Select * From eleve ORDER BY Nom");
            while(resultat.next())
            {
                model.addRow(new Object []{ resultat.getString("id_eleve"), resultat.getString("Nom"),resultat.getString("Prenom"),resultat.getString("ClasseElev")});
            }
        }
        catch(SQLException e)
        {
            System.out.println("Connexion echoué");
        }
    }        

    /**
     * Méthode qui initialise la fenetre permettant d'afficher la liste des éléves 
     */
    private void initComponents() {

        jLabel1 = new JLabel();
        tab = new JScrollPane();
        tabelev = new JTable();
        
        //setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times", 1, 32)); // NOI18N
        jLabel1.setText("Liste des éléves");
        
        tabelev.setModel(new DefaultTableModel(
            new Object [][] {
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null},
                {null, null, null,null}
            },
            new String [] 
            {
                "Id", "Nom", "Prénom","Classe"
            }
        ));
        tab.setViewportView(tabelev);


        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
      
        layout.setHorizontalGroup
        (
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup().addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 282,GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup().addContainerGap()
                .addComponent(tab, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        
        layout.setVerticalGroup
        (
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup().addContainerGap().addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tab, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        this.setVisible(true);


        }


}
